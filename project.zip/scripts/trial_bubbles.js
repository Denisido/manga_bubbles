import puppeteer from 'puppeteer';
import path from 'path';
import fs from 'fs';

// Получаем __dirname как в CommonJS
import { dirname } from 'path';
import { fileURLToPath } from 'url';
const __dirname = dirname(fileURLToPath(import.meta.url));

// Пути
const SCENARIO_PATH = path.join(__dirname, '../data/scenario.json');
const STATIC_IMAGE = path.join(__dirname, '../static/blank_1024.png');
const HTML_PATH = path.join(__dirname, '../index.html').replace(/\\/g, '/');
const OUTPUT_PATH = path.join(__dirname, '../trial/experiment.png');

// Читаем сценарий
const scenario = JSON.parse(fs.readFileSync(SCENARIO_PATH, 'utf-8'));

const run = async () => {
  const browser = await puppeteer.launch();
  const page = await browser.newPage();

  // Формируем query-параметры для режима trial
  const htmlUrl = `file://${HTML_PATH}?mode=trial&bg=${encodeURIComponent(STATIC_IMAGE)}&scenario=${encodeURIComponent(SCENARIO_PATH)}`;

  // Открываем страницу с нужными параметрами
  await page.goto(htmlUrl, { waitUntil: 'networkidle0' });

  // Передаем данные через window, если надо
  await page.evaluate((scenario, staticImage) => {
    window.trialScenario = scenario;
    window.trialBg = staticImage;
    window.trialMode = 'trial';
  }, scenario, STATIC_IMAGE);

  // Ожидаем, что render_bubbles.js повесит window.renderReady = true когда отрисовка закончится
  await page.waitForFunction('window.renderReady === true');

  // Даем время на рендер (можно увеличить при большом количестве пузырей)
  await page.waitForTimeout(300);

  // Делаем скриншот контейнера
  const container = await page.$('#container');
  await container.screenshot({ path: OUTPUT_PATH });

  await browser.close();
  console.log('Экспериментальный скриншот сохранён:', OUTPUT_PATH);
};

run();
